/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyServlets;

import MyBeans.SessionCounter;
import MyBeans.User;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 *
 * @author Lenovo
 */
@WebServlet(name = "LoginProcess", urlPatterns = {"/LoginProcess"})
public class LoginProcess extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    public HashMap<Integer, User> map = new HashMap<Integer, User>();
    public HashMap<Integer, User> mapInFile = new HashMap<Integer, User>();
    public HashMap<Integer, User> mapTemp = new HashMap<Integer, User>();

    public List userList = new ArrayList();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LoginProcess</title>");
            out.println("</head>");
            out.println("<body>");
            HttpSession session = request.getSession(false);
            String action = request.getParameter("action");

            if (session != null && session.getAttribute("username") != null) {
                //khi da log in thi se ko log in bang account khac duoc
                response.sendRedirect("/WebApp4/pages/profile.jsp");
            } else {

                if ("Sign Up".equals(action)) {
                    String newUsername = request.getParameter("newUsername");
                    String newPassword = request.getParameter("newPassword");
                    //if(validPass(newPassword)){
                    boolean checkUsername = true;
                    readFromFile();
                    Iterator ite = mapInFile.entrySet().iterator();
                    while (ite.hasNext()) {
                        Map.Entry me = (Map.Entry) ite.next();
                        User u = (User) me.getValue();
                        if (u.getUsername().equals(newUsername)) {
                            RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.jsp");
                            out.println("<font color=red>This username is already taken.</font>");
                            rd.include(request, response);
                            checkUsername = false;
                            break;
                        }
                    }
                    if (checkUsername) {
                        User user = new User();
                        user.setUsername(newUsername);
                        user.setPassword(newPassword);
                        int id = mapInFile.size() + 1;
                        user.setUserID(id);
                        mapInFile.put(id, user);
                        writeToFile(map, mapInFile, mapTemp);
                        RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.jsp");
                        out.println("<font color=green>You have signed up successfully, now you are able to sign in.</font>");
                        rd.include(request, response);
                    }
                } else if ("Sign In".equals(action)) {

                    String username = request.getParameter("username");
                    String password = request.getParameter("password");
                    readFromFile();
                    Iterator ite = mapInFile.entrySet().iterator();
                    boolean flag = false;
                    boolean loggedIn = false;
                    while (ite.hasNext()) {
                        Map.Entry me = (Map.Entry) ite.next();
                        User u = (User) me.getValue();
                        if (username.equals(u.getUsername()) && password.equals(u.getPassword())) {
                            for (Object user : userList) {
                                if (user.toString().equals(username)) {
                                    loggedIn = true;
                                }
                            }
                            if (loggedIn == false) {
                                userList.add(username);
                            }
                            flag = true;
                            break;
                        }
                    }
                    if (flag) {
                        session = request.getSession(true);
                        session.setAttribute("username", username);
                        session.setAttribute("userList", userList);
                        Cookie message = new Cookie("message", "Welcome");
                        message.setSecure(true);
                        message.setHttpOnly(true);
                        response.addCookie(message);
                        response.sendRedirect("/WebApp4/pages/profile.jsp");
                    } else {
                        RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.jsp");
                        out.println("<font color=red>Either username or password is wrong.</font>");
                        rd.include(request, response);
                    }
                }
            }
            out.println("</body>");
            out.println("</html>");
        }
    }

    public void writeToFile(HashMap<Integer, User> map, HashMap<Integer, User> map2, HashMap<Integer, User> map3) {
        try {
            File file = new File("users.txt");
            if (file.exists() && !file.isDirectory()) {
                readFromFile();
            }
            FileOutputStream fos = new FileOutputStream(file);
            PrintWriter pw = new PrintWriter(fos);
            if (map2 != null) {
                map3 = new HashMap<>(map);
                map3.putAll(map2);
                map = map3;
            }
            for (Map.Entry<Integer, User> m : map.entrySet()) {
                pw.println(m.getKey() + "=" + m.getValue().getUsername() + "=" + m.getValue().getPassword());
            }
            pw.flush();
            pw.close();
            fos.close();
        } catch (Exception e) {
        }
    }

    public void readFromFile() {
        try {
            File toRead = new File("users.txt");
            FileInputStream fis = new FileInputStream(toRead);
            Scanner sc = new Scanner(fis);
            //read data from file line by line:
            String currentLine;
            while (sc.hasNextLine()) {
                currentLine = sc.nextLine();
                User u = new User();
                //now tokenize the currentLine:
                StringTokenizer st = new StringTokenizer(currentLine, "=", false);
                //put tokens ot currentLine in map
                int i = Integer.parseInt(st.nextToken());
                u.setUsername(st.nextToken());
                u.setPassword(st.nextToken());
                mapInFile.put(i, u);
            }
            fis.close();
        } catch (Exception e) {

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        session.invalidate();

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

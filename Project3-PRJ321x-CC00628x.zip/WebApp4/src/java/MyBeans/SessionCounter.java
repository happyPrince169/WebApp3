/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyBeans;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 *
 * @author Lenovo
 */
public class SessionCounter implements HttpSessionListener {

    private int totalSessionCount = 0;
    private int currentSessionCount = 0;
    private int maxSessionCount = 0;
    private ServletContext context = null;
    private List userList = new ArrayList();

    public void sessionCreated(HttpSessionEvent event) {
        totalSessionCount++;
        currentSessionCount++;
        if (currentSessionCount > maxSessionCount) {
            maxSessionCount = currentSessionCount;
        }
        if (context == null) {
            storeInServletContext(event);
        }
    }

    //Khi xay ra ket thuc session cua user da dang nhap thanh cong
    public void sessionDestroyed(HttpSessionEvent event) {
        currentSessionCount--;
        if (event.getSession().getAttribute("username") != null) {
            userList = (List) event.getSession().getAttribute("userList");
            Iterator i = userList.iterator();
            String username = (String) event.getSession().getAttribute("username");
            Object user = null;
            while (i.hasNext()) {
                user = i.next();
                if (user.toString().equals(username)) {
                    userList.remove(user);
                    break;
                }
            }
        }
    }

    //Tong so sessions da tung tao ra
    public int getTotalSessionCount() {
        return (totalSessionCount);
    }

    //Sessions hien tai
    public int getCurrentSessionCount() {
        return (currentSessionCount);
    }

    //Sessions nhieu nhat cung luc
    public int getMaxSessionCount() {
        return (maxSessionCount);
    }

    //Store vao Sevlet Context
    private void storeInServletContext(HttpSessionEvent event) {
        HttpSession session = event.getSession();
        context = session.getServletContext();
        context.setAttribute("sessionCounter", this);
    }
}
